### This folder contains the components required to run the page in the remote server.

* HTML and JavaScript: To create parking layout and display real-time output to the user by using ajax.

* PHP files: 1) To connect to the remote database and the add the availability of parking slots to the database (ConnectDB.php).

             2) To retrive the latest data from the database based on time stamp (RetrieveData.php).

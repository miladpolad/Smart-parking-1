## This folder contains the python files required to run image processing algorithms on the data and further send the data to the remote server using URLLIB in python3.
